document.getElementById("nav-icons").addEventListener('click', function(){
    if(document.getElementById("nav-item-list").style.display == "block"){
        document.getElementById("nav-item-list").style.display ="none";
    }else{
        document.getElementById("nav-item-list").style.display ="block";
    }
})

// 